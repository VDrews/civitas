package civitas;

public enum Respuestas {
    NO, SI
}