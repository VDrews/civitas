package civitas;

public enum GestionesInmobiliarias {
    VENDER, HIPOTECAR, CANCELAR_HIPOTECA, CONSTRUIR_CASA, CONSTRUIR_HOTEL, TERMINAR
}