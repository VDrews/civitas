package civitas;

public enum OperacionesJuego {
    AVANZAR, COMPRAR, GESTIONAR, SALIR_CARCEL, PASAR_TURNO
}